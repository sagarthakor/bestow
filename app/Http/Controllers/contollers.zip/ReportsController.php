<?php

namespace App\Http\Controllers;

use App\Exports\OutOfStockExport;
use App\quotation;
use App\salesorder;
use App\company;
use App\stitching_machine;
use App\washing_machine;
use Illuminate\Http\Request;
use App\Exports\invoiceExport;
use App\Exports\quotationExport;
use App\Exports\salesExport;
use Excel;
use Illuminate\Support\Facades\DB;
use session;
use App\delivery_challan;
use App\Exports\challanExport;
use App\invoice;

class ReportsController extends Controller
{
    //
    function quotation(Request $request)
    {
        $product = new quotation();

        $quot_no=$client_name=$quot_date=$subject=$amount=$quot_stage="";
        $product=$product->select('quotation.*','customers.customer_name','customers.primary_email','customers.secondary_email','salesman.salesman_name');
        $product=$product->leftJoin('customers','customers.id','quotation.customer');
        $product=$product->leftJoin('salesman','salesman.id','quotation.salesman_id');
        if($request->quot_no != '')
        {
            $quot_no=$request->quot_no;
            $product = $product->Where('quotation.quotation_no','like','%'.$request->quot_no.'%');
        }
        if($request->client_name != '')
        {
            $product = $product->Where('quotation.customer_name','like','%'.$request->client_name.'%');
        }
        if(isset($request->salesman))
        {
            $salesmanName=$request->salesman;
            $product = $product->Where('salesman.salesman_name','like','%'.$salesmanName.'%');
        }
        if(isset($request->from_date) and isset($request->end_date))
        {
            $from=date('Y-m-d',strtotime($request->from_date));
            $to=date('Y-m-d',strtotime($request->end_date));
            $product = $product->whereBetween('quot_date',[$from,$to]);
        }
        if($request->subject != '')
        {
            $subject=$request->subject;
            $product = $product->Where('quotation.subject','like','%'.$request->subject.'%');
        }
        if($request->amount != '')
        {
            $amount=$request->amount;
            $product = $product->Where('quotation.grand_total','like','%'.$request->amount.'%');
        }
        if($request->quot_stage != '')
        {
            $quot_stage=$request->quot_stage;
            $product = $product->Where('quotation.quot_stage','like','%'.$request->quot_stage.'%');
        }
        if(isset($request->quotno_asc))
        {
            $product=$product->orderBy('quotation.quot_no','asc');
        }
        if(isset($request->quotno_desc))
        {
            $product=$product->orderBy('quotation.quot_no','desc');
        }
        if(isset($request->quot_date_asc))
        {
            $product=$product->orderBy('quotation.quot_date','asc');
        }
        if(isset($request->quot_date_desc))
        {
            $product=$product->orderBy('quotation.quot_date','desc');
        }

        if(isset($request->client_asc))
        {
            $product=$product->orderBy('quotation.customer_name','asc');
        }
        if(isset($request->client_desc))
        {
            $product=$product->orderBy('quotation.customer_name','desc');
        }

        if(isset($request->subject_asc))
        {
            $product=$product->orderBy('quotation.subject','asc');
        }
        if(isset($request->subject_desc))
        {
            $product=$product->orderBy('quotation.subject','desc');
        }

        if(isset($request->amount_asc))
        {
            $product=$product->orderBy('quotation.grand_total','asc');
        }
        if(isset($request->amount_desc))
        {
            $product=$product->orderBy('quotation.grand_total','desc');
        }
        if(isset($request->stage_asc))
        {
            $product=$product->orderBy('quotation.quot_stage','asc');
        }
        if(isset($request->stage_desc))
        {
            $product=$product->orderBy('quotation.quot_stage','desc');
        }

        $product=$product->orderBy('quotation.id','desc');
         $result = $product->paginate(10);
        $stage = array('Created' => 'Created', 'Sent' => 'Sent', 'Reviewing' => 'Reviewing', 'QuoteRivision' => 'QuoteRivision', 'Accepted' => 'Accepted', 'Invoiced' => 'Invoiced', 'Canceled' => 'Canceled');

       /* if(isset($request->tally_quotation))
        {
            return Excel::download(new InvoiceExport($request), 'quotation_tally.xlsx');
        }
        if(isset($request->export_excel))
        {
            return Excel::download(new quotationExport($request), 'QuotationReport.xlsx');
        }*/
        return view('admin.reports.quotation')
                ->with(['list'=>$result,'stage'=>$stage]);
    }

    function sales(Request $request)
    {
        $product = new salesorder();
        $salaesorder_no=$client_name=$quot_date=$subject=$amount=$quot_stage="";

        $product=$product->select('salesorder.*','customers.customer_name','customers.primary_email','customers.secondary_email','salesman.salesman_name');
        $product=$product->leftJoin('customers','customers.id','salesorder.customer');
        $product=$product->leftJoin('salesman','salesman.id','salesorder.salesman_id');

        if($request->salaesorder_no != '')
        {
            $salaesorder_no=$request->quot_no;
            $product = $product->Where('salesorder.salaesorder_no','like','%'.$request->salaesorder_no.'%');
        }

        if($request->client_name != '')
        {
            $product = $product->Where('salesorder.customer_name','like','%'.$request->client_name.'%');
        }

        if(isset($request->salesman))
        {
            $product = $product->Where('salesman.salesman_name','like','%'.$request->salesman.'%');
        }

        if(isset($request->from_date) and isset($request->end_date))
        {
            $from=date('Y-m-d',strtotime($request->from_date));
            $to=date('Y-m-d',strtotime($request->end_date));
            $product = $product->whereBetween('salaesorder_date',[$from,$to]);
        }
        if($request->subject != '')
        {
            $subject=$request->subject;
            $product = $product->Where('salesorder.subject','like','%'.$request->subject.'%');
        }
        if($request->amount != '')
        {
            $amount=$request->amount;
            $product = $product->Where('salesorder.grand_total','like','%'.$request->amount.'%');
        }
        if($request->status != '')
        {
            $status=$request->status;
            $product = $product->Where('salesorder.status','like','%'.$request->quot_stage.'%');
        }
        //echo print_r($request->all());

        $product=$product->orderBy("id",'desc');
        $product=$product->whereNull("delete_status");
        $result = $product->paginate(30);

        if(isset($request->export_excel))
        {
            return Excel::download(new salesExport($request), 'SalesReport.xlsx');
        }


        $company_name=company::select('company_name')->first();

        return view('admin.reports/sales')->with(['list'=>$result,'company'=>$company_name->company_name]);
    }

    function challan(Request $request)
    {
           $quot_no = $client_name = $quot_date = $subject = $amount = $quot_stage = "";

        $product = new delivery_challan();

        $quot_no=$client_name=$quot_date=$subject=$amount=$quot_stage="";

        $product=$product->select('delivery_challan.*','customers.customer_name','customers.primary_email','customers.secondary_email');
        $product=$product->leftJoin('customers','customers.id','delivery_challan.customer');

        if($request->invoice_no != '')
        {
            $quot_no=$request->quot_no;
            $product = $product->Where('delivery_challan.challan_number','like','%'.$request->invoice_no.'%');
        }
        if($request->client_name != '')
        {
            $client_name=$request->client_name;
            $product = $product->Where('customers.customer_name','like','%'.$request->client_name.'%');
        }
        if(isset($request->from_date) and isset($request->end_date))
        {
            $from=date('Y-m-d',strtotime($request->from_date));
            $to=date('Y-m-d',strtotime($request->end_date));
            $product = $product->whereBetween('delivery_challan.invoice_date',[$from,$to]);
        }
        if($request->subject != '')
        {
            $subject=$request->subject;
            $product = $product->Where('delivery_challan.subject','like','%'.$request->subject.'%');
        }
        if($request->amount != '')
        {
            $amount=$request->amount;
            $product = $product->Where('delivery_challan.grand_total','like','%'.$request->amount.'%');
        }
        if($request->status != '')
        {
            $quot_stage=$request->status;
            $product = $product->Where('delivery_challan.status','like','%'.$request->status.'%');
        }


        //echo print_r($request->all());
        $product = $product->where('delivery_challan.finacial_year', Session::get('finacial_year_id'));
        $product = $product->whereNull('delivery_challan.delete_status');
        $product=$product->orderBy('delivery_challan.id','desc');
        $result = $product->paginate(30);

        if(isset($request->export_excel))
        {
            return Excel::download(new challanExport($request), 'ChallanReport.xlsx');
        }

        $company_name = company::select('company_name')->first();


        $stage = array('Created' => 'Created', 'Sent' => 'Sent', 'Reviewing' => 'Reviewing', 'QuoteRivision' => 'QuoteRivision', 'Accepted' => 'Accepted', 'Invoiced' => 'Invoiced', 'Canceled' => 'Canceled');


        return view("admin.reports.challan")->with(['list' => $result, 'company' => $company_name->company_name, 'stage' => $stage]);
    }

    function invoice(Request $request)
    {
          $quot_no = $client_name = $quot_date = $subject = $amount = $quot_stage = "";

        $product = new invoice();

        $quot_no=$client_name=$quot_date=$subject=$amount=$quot_stage="";

        $product=$product->select('invoice.*','customers.customer_name','customers.primary_email','customers.secondary_email','salesman.salesman_name');
        $product=$product->leftJoin('customers','customers.id','invoice.customer');
        $product=$product->leftJoin('salesman','salesman.id','invoice.salesman_id');

        if($request->invoice_no != '')
        {
            $product = $product->Where('invoice.invoice_number','like','%'.$request->invoice_no.'%');
        }

        if($request->client_name != '')
        {
            $product = $product->Where('customers.customer_name','like','%'.$request->client_name.'%');
        }
        if(isset($request->salesman))
        {
            $product = $product->Where('salesman.salesman_name','like','%'.$request->salesman.'%');
        }
        if(isset($request->from_date) and isset($request->end_date))
        {
            $from=date('Y-m-d',strtotime($request->from_date));
            $to=date('Y-m-d',strtotime($request->end_date));
            $product = $product->whereBetween('invoice.invoice_date',[$from,$to]);
        }
        if($request->subject != '')
        {
            $subject=$request->subject;
            $product = $product->Where('invoice.subject','like','%'.$request->subject.'%');
        }
        if($request->amount != '')
        {
            $amount=$request->amount;
            $product = $product->Where('invoice.grand_total','like','%'.$request->amount.'%');
        }
        if($request->status != '')
        {
            $quot_stage=$request->status;
            $product = $product->Where('invoice.status','like','%'.$request->status.'%');
        }


        $product=$product->orderBy('invoice.id','desc');
        $result = $product->paginate(10);

        $company_name = company::select('company_name')->first();



        $stage = array('Created' => 'Created', 'Sent' => 'Sent', 'Reviewing' => 'Reviewing', 'QuoteRivision' => 'QuoteRivision', 'Accepted' => 'Accepted', 'Invoiced' => 'Invoiced', 'Canceled' => 'Canceled');

       /* if(isset($request->export_excel))
        {
            return Excel::download(new invoiceExport($request), 'InvoicesReport.xlsx');
        }*/

        return view("admin.reports.invoice")->with(['list' => $result, 'company' => $company_name->company_name, 'stage' => $stage]);
    }

    public function salesOutOfStockItems(Request $request)
    {
        $categories    = DB::table('category')->orderBy('category_name')->get();
        $subcategories = DB::table('subcategory')->orderBy('subcategory_name')->get();

        // Step 1: one row per (product, sales order) with that order's own sold qty,
        // plus how much stock had actually been received (production/purchase/transfer,
        // from the stock_book ledger) for that product as of that order's date. This
        // lets restocks that happen BETWEEN orders correctly top up later orders'
        // balance, instead of treating today's stock as if it existed since day one.
        // Built over the FULL order history (no filters) so the running balance below
        // is correct regardless of which rows the user later chooses to display.
        $perOrder = DB::table('salesorder_item as soi')
            ->join('salesorder as s', 's.id', '=', 'soi.soid')
            ->join('product as p', 'p.id', '=', 'soi.product')
            ->leftJoin('category as cat', 'cat.id', '=', 'p.category')
            ->leftJoin('subcategory as sc', 'sc.id', '=', 'p.subcategory')
            ->whereNull('s.delete_status')
            ->groupBy(
                'soi.product',
                'p.product_name',
                'p.category',
                'p.subcategory',
                's.id',
                's.salaesorder_no',
                's.customer_name',
                's.salaesorder_date',
                'cat.category_name',
                'sc.subcategory_name'
            )
            ->select(
                'soi.product as product_id',
                'p.product_name as product',
                'p.category as category_id',
                'p.subcategory as subcategory_id',
                's.id as so_id',
                's.salaesorder_no as order_no',
                's.customer_name as customer',
                's.salaesorder_date as order_date',
                'cat.category_name as category_name',
                'sc.subcategory_name as subcategory_name',
                DB::raw('SUM(soi.qty) as sold_qty'),
                DB::raw('(SELECT IFNULL(SUM(sb.inward_qty), 0) FROM stock_book sb
                    WHERE sb.product = soi.product
                      AND sb.inward_qty IS NOT NULL
                      AND sb.inward_date <= s.salaesorder_date) as stock_qty')
            );

        // Step 2: running/cumulative balance per product, in chronological order,
        // so an order's balance reflects stock received so far minus everything
        // ordered up to and including that order - not stock received/ordered later.
        $running = DB::query()
            ->fromSub($perOrder, 't')
            ->select('t.*')
            ->selectRaw('SUM(t.sold_qty) OVER (PARTITION BY t.product_id ORDER BY t.order_date, t.so_id) as cumulative_sold_qty')
            ->selectRaw('(t.stock_qty - SUM(t.sold_qty) OVER (PARTITION BY t.product_id ORDER BY t.order_date, t.so_id)) as balance');

        // Step 3: display "stock qty" as today's actual on-hand stock (stock_status),
        // not a derived historical figure. The running balance above still decides
        // WHICH rows qualify as insufficient-stock; it's just not shown as a column.
        $query = DB::query()
            ->fromSub($running, 'w')
            ->leftJoin('stock_status as ss', 'ss.product', '=', 'w.product_id')
            ->select(
                'w.product_id',
                'w.product',
                'w.category_id',
                'w.subcategory_id',
                'w.so_id',
                'w.order_no',
                'w.customer',
                'w.order_date',
                'w.category_name',
                'w.subcategory_name',
                'w.sold_qty'
            )
            ->selectRaw('IFNULL(ss.qty, 0) as stock_qty')
            ->selectRaw('ABS(w.sold_qty - IFNULL(ss.qty, 0)) as need_to_purchase_qty')
            ->where('w.balance', '<=', 0)
            // Already delivered (fully covered by a Delivery Challan) = resolved,
            // not "at risk" anymore, so don't flag it as insufficient stock.
            ->whereRaw('IFNULL((
                    SELECT SUM(dci.qty)
                    FROM delivery_challan_item dci
                    JOIN delivery_challan dc ON dc.id = dci.invid
                    WHERE dc.delete_status IS NULL
                      AND dc.salaesorder_no = w.order_no
                      AND dci.product = w.product_id
                ), 0) < w.sold_qty')
            ->orderBy('w.order_date', 'desc');

        // Filters (applied after the running balance is computed, so they only
        // control which rows are displayed - not the balance calculation itself)
        if ($request->product) {
            $query->where('w.product', 'like', '%' . $request->product . '%');
        }

        if ($request->order_no) {
            $query->where('w.order_no', 'like', '%' . $request->order_no . '%');
        }

        if ($request->customer) {
            $query->where('w.customer', 'like', '%' . $request->customer . '%');
        }

        if ($request->from_date) {
            $query->whereDate('w.order_date', '>=', $request->from_date);
        }

        if ($request->end_date) {
            $query->whereDate('w.order_date', '<=', $request->end_date);
        }

        if ($request->category) {
            $query->where('w.category_id', $request->category);
        }

        if ($request->subcategory) {
            $query->where('w.subcategory_id', $request->subcategory);
        }

        // Export must be checked BEFORE paginate to export all records
        if ($request->export_excel) {
            $data = $query->get();
            return Excel::download(new OutOfStockExport($data), 'out_of_stock.xlsx');
        }

        // Summary stats over the FULL filtered result set (not just this page).
        // Replace the select list entirely - can't mix these aggregates with the
        // row-level columns already selected on $query without a GROUP BY.
        $summary = (clone $query)
            ->reorder()
            ->select(DB::raw('
                COUNT(DISTINCT w.product_id) as affected_products,
                COUNT(DISTINCT w.order_no) as affected_orders,
                SUM(w.sold_qty) as total_sold_qty
            '))
            ->first();

        $list = $query->paginate(20);

        return view('admin.reports.sales_out_of_stock', compact('list', 'categories', 'subcategories', 'summary'));
    }

}
