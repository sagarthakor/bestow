@extends('admin.layout.table_master')

@section('title', 'List | Formula')

@section('sidebar')
    @parent

@endsection

@section('content')


    <!-- ============================================================== -->
    <!-- Start right Content here -->
    <!-- ============================================================== -->
    <div class="content-page">
        <!-- Start content -->
        <div class="content">
            <div class="container">


                <div class="row">
                    <div class="col-xs-12">
                        <div class="page-title-box">
                            <h4 class="page-title">{{Session::get('software_title')}} </h4>
                            <ol class="breadcrumb p-0 m-0">
                                <li>
                                    <a href="#">{{Session::get('software_title')}}</a>
                                </li>
                                <li class="active">
                                    <a href="#">Formula List </a>
                                </li>
                                @foreach(Session::get('child_module') as $child)
                                    @if($child->submodule_name=="Category" and $child->module_add=='1')
                                        <li style="text-align: right;margin-bottom: 5px">
                                            <a class="btn btn-primary" href="{{url('formula_mst/add')}}">Add New</a>
                                        </li>
                                    @endif
                                @endforeach
                            </ol>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
                <!-- end row -->






                <div class="row">
                    <div class="col-sm-12">
                        <div class="card-box table-responsive">

                            @if(session()->has('message'))
                                <div class="col-sm-12">
                                    <div class="alert alert-info" style="background-color: #188ae2 !important">
                                        <strong style="color: #fff">{{session()->get('message')}}</strong>
                                    </div>
                                </div>
                            @endif
                            <table class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0"
                                   width="100%">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Product</th>
                                    <th>Nos.</th>
                                    <th>Size.</th>
                                    <th>Total Material.</th>
                                  
                                    <th></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                $srno=0;
                                ?>
                                @foreach($data as $list)
                                    <?php
                                    $srno++;
                                    ?>
                                    <tr>
                                        <td style="width: 5%"> {{$srno}}</td>
                                        <td style="text-align:center"><a  target="_blank" title="View" href="{{url('formula_view/'.$list->id)}}">{{$list->product_name}}</a></td>
                                        <td style="text-align:center">{{$list->nos}}</td>
                                        <td style="text-align:center">{{$list->size}}</td>
                                        <td style="text-align:center">{{$list->required_qty}}</td>
                                       
                                        <td class="actions" style="width: 10%">
                                            @foreach(Session::get('child_module') as $child)
                                                @if($child->submodule_name=="Category" and $child->module_edit=='1')
                                                    <a href="{{url('formula_mst/edit/'.$list->id)}}" class="on-default edit-row"><i class="fa fa-pencil"></i></a>
                                                @endif
                                                @if($child->submodule_name=="Category" and $child->module_delete=='1')
                                                    <a href="{{url('formula_mst/delete/'.$list->id)}}" class="on-default remove-row" onclick="return confirm('Are you sure you want to delete this item?');"><i class="fa fa-trash-o"></i></a>
                                                @endif
                                            @endforeach


                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                            {{$data->links()}}

                        </div>
                    </div>
                </div>



                <!-- end row -->



            </div> <!-- container -->

        </div> <!-- content -->

@endsection
